import json
import os

class ConfigManager:
    def __init__(self):
        # 构造正确的config.json路径
        self.config_path = os.path.join(os.path.dirname(__file__), 'config.json')
        # 读取并解析JSON文件
        with open(self.config_path, 'r', encoding='utf-8') as f:
            self.config_data = json.load(f)

    def TMDBApi(self):
        # 提取TMDB_API的值（自动处理键不存在的情况）
        tmdb_api = self.config_data.get('TMDB_API', '未找到TMDB_API配置')
        if tmdb_api == "your_api_key_here":
            print("未找到TMDB_API配置")
        else:
            print(tmdb_api)
        return tmdb_api

    def langage(self):
        # 提取langage的值（自动处理键不存在的情况）
        langage = self.config_data.get('langage', '未找到langage配置')
        if langage == "":
            print("未找到langage配置")
        else:
            print(langage)
        return langage
    
    def RenameRules(self):
        # 提取RenameRule的值（自动处理键不存在的情况）
        RenameRule = self.config_data.get('RenameRule', '未找到RenameRule配置')
        if RenameRule == "":
            print("未找到RenameRule配置")
        else:
            print(RenameRule)
        return RenameRule
