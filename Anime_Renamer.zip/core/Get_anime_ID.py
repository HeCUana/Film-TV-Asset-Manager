import logging
import requests
import sys
import os
from config import ConfigManager

# 配置日志记录
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
# 动态获取项目根目录并添加到模块搜索路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(project_root)

        
class AnimeIDGetter(ConfigManager):
    """
    用于根据动漫名称获取TMDB（The Movie Database）上的动漫ID。

    该类提供了一个方法 `get_anime`，用于根据输入的动漫名称和TMDB API密钥，
    从TMDB API获取对应的动漫ID。

    Args:
        AnimeName (str): 要查询的动漫名称。
        TMDB_API (str): TMDB API密钥，用于身份验证和访问TMDB数据库。

    Attributes:
        AnimeName (str): 存储的动漫名称，用于查询TMDB上的对应ID。
        TMDB_API (str): 存储的TMDB API密钥，用于身份验证。

    Methods:
        FetchAnimeID() -> int:
            根据动漫名称查询TMDB上的动漫ID。

            返回:
                int: 查询到的动漫ID，如果查询失败或未找到对应ID，则返回None。
    """
    def __init__(self, AnimeName: str, ConfigManager) -> None:
        self.AnimeName = AnimeName
        self.TMDB_API = ConfigManager.TMDBApi()

    def FetchAnimeID(self) -> int:
        """
        根据动漫名称获取动漫对应的id值
        - 输入:
            - AnimeName:动漫名称（通过初始化传入）
            - TMDB_API: TMDB_API密钥（通过初始化传入）
        - 输出：
            - tv_id:查询到的tv_id，如果查询失败或未找到对应ID，则返回None。
        """
        url = f'https://api.themoviedb.org/3/search/multi?api_key={self.TMDB_API}&query={self.AnimeName}'
        try:
            response = requests.get(url)
            response.raise_for_status()
            data = response.json()
            if data.get('results'):
                tv_id = data['results'][0].get('id')
                logging.info("找到的TV节目的ID: %s", tv_id)
                return tv_id
            else:
                logging.warning("没有找到对应的TV节目的ID")
                return None
        except requests.RequestException as e:
            logging.error("API请求失败: %s", e)
            return None
