from core.Get_anime_ID import AnimeIDGetter
from config import ConfigManager

anime_getter = AnimeIDGetter(AnimeName="名侦探柯南")
a = anime_getter.FetchAnimeID()
print(a)
